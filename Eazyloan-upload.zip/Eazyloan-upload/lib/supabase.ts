import { createBrowserClient } from '@supabase/ssr'
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://placeholder.supabase.co'
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_build_placeholder'
export const supabase = createBrowserClient(supabaseUrl, supabaseKey)
export const loanPurposes = ['Home Improvement','Debt Consolidation','Education','Auto Purchase','Business','Medicals','Personal','Others'] as const
export const tenures = [3,6,12,24] as const
export type Status = 'Pending'|'Under Review'|'Approved'|'Rejected'
