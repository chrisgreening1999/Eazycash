'use client'
import { useState } from 'react'
import { supabase } from '../lib/supabase'
export default function Login() {
  const [busy,setBusy]=useState(false); const [error,setError]=useState('')
  async function signIn(){setBusy(true);setError(''); const {error}=await supabase.auth.signInWithOAuth({provider:'google',options:{redirectTo:`${window.location.origin}/dashboard`}}); if(error)setError(error.message);setBusy(false)}
  return <main className="auth-shell"><section className="auth-card"><div className="auth-hero"><div><div className="wordmark"><span className="mark">e</span> Eazyloan</div><h1>Loans made easy.</h1><p>Get the support you need, when you need it.</p></div><div className="hero-orb">₵</div></div><div className="auth-body"><div className="eyebrow">EAZYLOAN ACCOUNT</div><h2>Welcome Back!</h2><p className="muted">Sign in securely with your Google account to continue your loan application journey.</p><button className="google-btn" onClick={signIn} disabled={busy}><span className="google-mark">G</span>{busy?'Connecting…':'Continue with Google'}</button>{error&&<p className="error">{error}</p>}<p className="fineprint">By continuing, you agree to our terms and data sharing policy.</p></div></section></main>
}
