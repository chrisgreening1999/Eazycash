export { default } from '../page'
