export default { logoUrl: "https://lrcxinwmdliegzrathag.supabase.co/storage/v1/object/public/brand/eazyloan-mark.png" };
