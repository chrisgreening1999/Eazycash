# Eazyloan

A responsive Supabase-backed loan application website for Vercel. The repository was initially empty; this source tree implements the agreed customer flow, loan form, customer application history, and the SQL security foundation for the admin workflow.

## Local setup

1. Copy `.env.example` to `.env.local` and add the Supabase project URL, publishable key, site URL, and server-only service-role key where required.
2. Run `npm install` then `npm run dev`.
3. In Supabase SQL Editor, review and run `supabase/migrations/20261120145000_eazyloan_schema.sql` against the intended project. The migration was written but not executed by this package task because no database credential or migration connection was provided.
4. Enable Google in Supabase Auth, add the local and Vercel redirect URLs, and configure Google OAuth client credentials in Supabase/provider settings.
5. After the designated administrator signs in, provision the `admin` role in a controlled backend SQL/session using the verified Auth user ID; do not grant it from the browser.

## Implemented

- Green-and-white Eazyloan sign-in composition with real Supabase Google OAuth initiation.
- Responsive dashboard, apply-for-loan form, application history, and profile pages.
- Required fields, exact supplied explanatory notes, one-purpose selection, amount/tenure validation, required terms acceptance, and multiple application records.
- Versioned SQL migration with core tables, backend constraints, auth trigger, status history, audit table, RLS, and admin helper.
- No service-role key, OAuth secret, or administrator email is embedded in frontend code.
- Supplied login reference preserved at `public/references/eazyloan-login-reference.jpeg`.

## Owner confirmations still needed before public launch

- Whether the MoMo note should continue to say “verification purposes” even though the number is for disbursement.
- Whether submitted applications are editable (the current UI uses a safe no-edit-after-submit behavior).
- The exact restoration/unblock workflow for suspended accounts.
- Legal/privacy review of the supplied statements.

## Deployment

Use Vercel with the same environment variables and configure Supabase Auth redirect URLs for the final Vercel domain. Do not commit `.env.local` or any service-role key.
